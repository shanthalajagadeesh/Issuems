package com.example.issuems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssuemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
