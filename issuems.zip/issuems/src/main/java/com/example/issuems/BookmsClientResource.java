package com.example.issuems;

import com.example.issuems.Domain.Book;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;


@RestController
public class BookmsClientResource {
    private static final Logger LOGGER = LoggerFactory.getLogger(BookmsClientResource.class);
    @Autowired
    private WebClient webClient;

    @GetMapping("/client-bookms")
    @CircuitBreaker(name="issuemsClient", fallbackMethod = "bookmsfallback")
    public Mono getBookFromBookms() {
        LOGGER.info("about to call bookms from issuems");
        return webClient.get().uri("/books").retrieve().bodyToMono(Object.class);
    }
    @PutMapping ("/update-bookms/{isbn}")
    public Mono<Book> updateBookFromIssuems(@PathVariable Long isbn, @RequestBody Book book) {
        return webClient.put()
                .uri("/book/{isbn}", isbn)
                .bodyValue(book)
                .retrieve()
                .bodyToMono(Book.class);
    }
    private Mono bookmsfallback(CallNotPermittedException ex) {
        LOGGER.error("fallback invoked");
        return Mono.just("CalledFromCache");
    }
}
