package com.example.issuems.api;

import com.example.issuems.Domain.Issue;
import com.example.issuems.Repo.IssueRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import static org.springframework.http.ResponseEntity.*;
import static org.springframework.http.ResponseEntity.notFound;

@RestController
@RequestMapping("/api/issues")
public class IssueResource {
    private static final Logger LOGGER = LoggerFactory.getLogger(IssueResource.class);
    @Autowired
    private IssueRepo issuerepo; // Dependency Injection

    @GetMapping("/Issue")
    public List<Issue> getAllIssue() {
        LOGGER.info("Getting all Issued books from database");
        return issuerepo.findAll();
    }

    @GetMapping("/Issue/{isbn}")
    public ResponseEntity<Issue> getIsbn(@PathVariable String isbn) {
        LOGGER.info("Getting Book Issued based on book id {} from database", isbn);
        Optional<Issue> issueFound = issuerepo.findById(Long.valueOf(isbn));
        if (issueFound.isPresent()) {
            LOGGER.info("Books issued with isbn {} from database", isbn);
            return ok((Issue) issueFound.get()); // returns http status code of 200
        }
        LOGGER.error("books issue NOT Found for isbn {} from database", isbn);
        return notFound().build(); // returns http status code of 404
    }
    @PostMapping("/issues")
    public ResponseEntity<Issue> addissue(@org.springframework.web.bind.annotation.RequestBody Issue issue) {
        LOGGER.info("Saving book issue into database");
        Issue savedissue = issuerepo.save(issue);
        LOGGER.info("book issue saved into database with isbn generated as {}", savedissue.getIsbn());
        return created(URI.create(savedissue.getIsbn().toString())).body(savedissue);// returns http status code of 201
    }
    @DeleteMapping("/issue/{isbn}")
    public ResponseEntity<Issue> deleteBookByIsbn(@PathVariable Long isbn) {
        LOGGER.info("deleting single book issue with isbn {} from database", isbn);
        Optional<Issue> issueFound = issuerepo.findById(isbn);
        if (issueFound.isPresent()) {
            issuerepo.delete(issueFound.get());
            LOGGER.info("book issue deleted with isbn {} from database", isbn);
            return ok(issueFound.get()); // returns http status code of 200
        }else  {
            LOGGER.warn("book with isbn {} not found in database", isbn);
            return notFound().build(); // returns http status code of 404
        }
    }

    @PutMapping("/issue/{isbn}")
    public ResponseEntity<Issue> updateBookByIsbn(@RequestBody Issue issue, @PathVariable Long isbn) {
        LOGGER.info("update book issue with isbn {} from database", isbn);
        Optional<Issue> updating = issuerepo.findById(isbn);
        if (updating.isPresent()) {
            issue.setIsbn(String.valueOf(Long.valueOf(isbn)));
            Issue savedissue = issuerepo.save(issue);
            LOGGER.info("book issue updated with isbn {} from database", isbn);
            return ResponseEntity.ok(savedissue);// returns http status code of 200
        }else  {
            LOGGER.warn("book with isbn {} not found in database", isbn);
            return notFound().build(); // returns http status code of 404
        }
    }
}
