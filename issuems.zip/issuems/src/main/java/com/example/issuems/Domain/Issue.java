package com.example.issuems.Domain;


import jakarta.persistence.*;

@Entity
@Table(name = "IssueBook_data")
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long isbn; //isbn as primary key
    private String custId; //customer ID
    private Integer noOfCopies;

    public void setIsbn(String isbn) {
        this.isbn = Long.valueOf(isbn);
    }
    public Long getIsbn() {
        return isbn;
    }
    public void setCustId(String custId) {
        this.custId = custId;
    }
    public String getCustId() {
        return custId;
    }
    public void setNoOfCopies(Integer noOfCopies) {
        this.noOfCopies = noOfCopies;
    }
    public Integer getNoOfCopies() {
        return noOfCopies;
    }
}

